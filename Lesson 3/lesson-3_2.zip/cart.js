class Cart {
    constructor (a, b, f){
        this.
    }
}

let m = new Cart();