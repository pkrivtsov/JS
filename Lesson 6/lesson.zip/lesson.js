document.querySelector('#like-btn')
    .addEventListener('click', (e) => {
        e.stopPropagation()
        const countEl = document.querySelector('#like-count');
        const count = Number(countEl.textContent);
        countEl.textContent = count + 1;
    })

document.querySelector('#post')
    .addEventListener('click', (e) => {
        alert('добавлен в корзину')
    })